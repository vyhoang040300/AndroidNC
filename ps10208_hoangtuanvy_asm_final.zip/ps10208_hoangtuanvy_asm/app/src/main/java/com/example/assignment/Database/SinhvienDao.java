package com.example.assignment.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assignment.Model.SinhVien;

import java.util.ArrayList;

public class SinhvienDao {
    SQLiteDatabase db;

    public SinhvienDao(Context context) {
        DBHelper dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public ArrayList<SinhVien> laytatcasinhvien(String MALOP) {
        ArrayList<SinhVien> danhsach = new ArrayList<>();
        Cursor c = db.query("SINHVIEN", null, "MALOP=?", new String[]{MALOP}, null, null, null);
        while (c.moveToNext()) {
            SinhVien sv = new SinhVien();

            sv.setMasv(c.getString(c.getColumnIndex("MASV")));
            sv.setTensv(c.getString(c.getColumnIndex("TENSV")));
            sv.setNgaysinh(c.getString(c.getColumnIndex("NGAYSINH")));
            sv.setMalop(c.getString(c.getColumnIndex("MALOP")));
            danhsach.add(sv);
        }
        return danhsach;
    }

    public long ThemSinhVien(SinhVien sv) {
        ContentValues values = new ContentValues();
        values.put("MASV",sv.getMasv());
        values.put("MALOP",sv.getMalop());
        values.put("TENSV", sv.getTensv());
        values.put("NGAYSINH", sv.getNgaysinh());


        return db.insert("SINHVIEN", null, values);

    }
    public long SuaThongTin(SinhVien sv){
        ContentValues values = new ContentValues();
         values.put("MASV",sv.getMasv());
        values.put("TENSV", sv.getTensv());
        values.put("NGAYSINH", sv.getNgaysinh());

        return  db.update("SINHVIEN",values,"MASV=?",new String[]{sv.getMasv()});
    }
    public int XoaSV(SinhVien sv){
        return db.delete("SINHVIEN","MASV=?",new String[]{sv.getTensv()});
    }
}
