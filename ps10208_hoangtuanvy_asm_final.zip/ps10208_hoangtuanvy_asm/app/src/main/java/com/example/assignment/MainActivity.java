package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.assignment.NewT.Tintuc;

public class MainActivity extends AppCompatActivity {
Button btnsccial,btnmap,btnnew,btncourse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        anhxa();
        btncourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(MainActivity.this,CourseActivity.class);
                startActivity(intent);
            }
        });
        btnsccial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(MainActivity.this,Social.class);
                startActivity(intent);
            }
        });
        btnmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, APIMap.class);
                startActivity(intent);
            }
        });
        btnnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Tintuc.class);
                startActivity(intent);
            }
        });
    }

    private void anhxa() {
        btnsccial =findViewById(R.id.btnsocial);
        btnmap =findViewById(R.id.btnMaps);
        btnnew =findViewById(R.id.btnNew);
        btncourse = findViewById(R.id.btncourse);
    }
}
