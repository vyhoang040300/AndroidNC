package com.example.assignment.Model;

public class Lophoc {

    String Malop;
    String Tenlop;

    public Lophoc(String malop, String tenlop) {

        Malop = malop;
        Tenlop = tenlop;
    }

    public Lophoc() {
    }



    public String getMalop() {
        return Malop;
    }

    public void setMalop(String malop) {
        Malop = malop;
    }

    public String getTenlop() {
        return Tenlop;
    }

    public void setTenlop(String tenlop) {
        Tenlop = tenlop;
    }
}
