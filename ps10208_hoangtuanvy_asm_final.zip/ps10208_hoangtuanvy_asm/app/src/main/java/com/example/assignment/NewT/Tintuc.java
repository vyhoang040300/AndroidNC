package com.example.assignment.NewT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.webkit.WebView;

import com.example.assignment.Adapter.AdapterListNews;
import com.example.assignment.Model.News;
import com.example.assignment.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import static com.example.assignment.NewT.Webview.LINK_ARGS;

public class Tintuc extends AppCompatActivity implements AdapterListNews.Listener {
    private RecyclerView recyclerView;
    private AdapterListNews adapterListNews;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tintuc);
        recyclerView = findViewById(R.id.list_news);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterListNews = new AdapterListNews(this);
        recyclerView.setAdapter(adapterListNews);

        NewsSeedAsyncTask newsSeedAsyncTask = new NewsSeedAsyncTask();
        newsSeedAsyncTask.execute();
    }
    @Override
    public void onClickNews(News news) {
        Intent i = new Intent(this, WebView.class);
        i.putExtra(LINK_ARGS, news.getLink());
        startActivity(i);
    }

    @SuppressLint("StaticFieldLeak")
    class NewsSeedAsyncTask extends AsyncTask<Void, Void, List<News>> {

        @Override
        protected List<News> doInBackground(Void... voids) {
            try {
                URL url = new URL("https://vnexpress.net/rss/thoi-su.rss");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                return NewReader.listNews(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<News> news) {
            super.onPostExecute(news);
            if (news != null) {
                adapterListNews.setListNews(news);
            }
        }
    }
}
