package com.example.assignment.Model;

public class SinhVien {

    String Masv;
    String Tensv;
    String Ngaysinh;
    String Malop;

    public SinhVien(String masv, String tensv, String ngaysinh, String malop) {

        Masv = masv;
        Tensv = tensv;
        Ngaysinh = ngaysinh;
        Malop = malop;
    }

    public SinhVien() {
    }





    public String getTensv() {
        return Tensv;
    }

    public void setTensv(String tensv) {
        Tensv = tensv;
    }

    public String getNgaysinh() {
        return Ngaysinh;
    }

    public void setNgaysinh(String ngaysinh) {
        Ngaysinh = ngaysinh;
    }

    public String getMalop() {
        return Malop;
    }

    public void setMalop(String malop) {
        Malop = malop;
    }

    public String getMasv() {
        return Masv;
    }

    public void setMasv(String masv) {
        Masv = masv;
    }
}
