package com.example.assignment.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assignment.Model.Lophoc;

import java.util.ArrayList;

public class LopDao {
    SQLiteDatabase db;

    public LopDao(Context context) {
        DBHelper dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public ArrayList<Lophoc> laytatcalop() {
        ArrayList<Lophoc> danhsach = new ArrayList<>();
        Cursor c = db.query("LOPHOC", null, null, null, null, null, null);
        while (c.moveToNext()) {
            Lophoc lh = new Lophoc();

            lh.setMalop(c.getString(c.getColumnIndex("MALOP")));
            lh.setTenlop(c.getString(c.getColumnIndex("TENLOP")));

            danhsach.add(lh);
        }
        return danhsach;
    }
    public long ThemLop(Lophoc lh){
        ContentValues values = new ContentValues();

        values.put("MALOP",lh.getMalop());
        values.put("TENLOP",lh.getTenlop());

        return db.insert("LOPHOC",null,values);

    }
    public int SuaLop(Lophoc lh){
        ContentValues values = new ContentValues();

        values.put("MALOP",lh.getMalop());
        values.put("TENLOP",lh.getTenlop());
        return  db.update("LOPHOC",values,"MALOP=?",new String[]{lh.getMalop()});
    }
    public int XoaLop(Lophoc lh){
        return db.delete("LOPHOC","MALOP=?",new String[]{lh.getMalop()});
    }
}
