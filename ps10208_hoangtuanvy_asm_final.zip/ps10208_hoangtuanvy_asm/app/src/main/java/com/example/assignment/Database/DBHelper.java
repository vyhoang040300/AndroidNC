package com.example.assignment.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public final static String DBNAME = "QUANLYSINHVIEN";
    public final static int DBVERSION = 7;
    public DBHelper(Context context){super(context,DBNAME,null,DBVERSION);}
    final String LOPHOC="CREATE TABLE LOPHOC(MALOP TEXT NOT NULL PRIMARY KEY," +
            "TENLOP TEXT NOT NULL)";
    final String SINHVIEN="CREATE TABLE SINHVIEN(MASV TEXT NOT NULL PRIMARY KEY,"+
            "TENSV TEXT NOT NULL," +
            "NGAYSINH DATETIME NOT NULL," +
            "MALOP TEXT , FOREIGN KEY (MALOP) REFERENCES LOPHOC(MALOP))";

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(LOPHOC);
        db.execSQL(SINHVIEN);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql1= "DROP TABLE LOPHOC";
        String sql2= "DROP TABLE SINHVIEN";
        db.execSQL(sql1);
        db.execSQL(sql2);
        onCreate(db);
    }
}
